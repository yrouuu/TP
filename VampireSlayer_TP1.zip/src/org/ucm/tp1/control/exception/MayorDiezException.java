package org.ucm.tp1.control.exception;

public class MayorDiezException extends CommandExecuteException{

	

	public MayorDiezException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
