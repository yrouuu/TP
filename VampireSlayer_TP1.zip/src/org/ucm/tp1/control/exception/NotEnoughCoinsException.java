package org.ucm.tp1.control.exception;

public class NotEnoughCoinsException extends CommandExecuteException{



	public NotEnoughCoinsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
