package org.ucm.tp1.control.exception;

public class DraculaIsAliveException extends CommandExecuteException{

	
	public DraculaIsAliveException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
