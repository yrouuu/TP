package org.ucm.tp1.control.exception;

public class NoMoreVampiresException extends CommandExecuteException{

	public NoMoreVampiresException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoMoreVampiresException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
