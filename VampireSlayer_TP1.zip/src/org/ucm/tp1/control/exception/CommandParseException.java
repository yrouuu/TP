package org.ucm.tp1.control.exception;

public class CommandParseException extends GameException{


	public CommandParseException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
}
