package org.ucm.tp1.control.exception;

public class CommandExecuteException extends GameException{

	public CommandExecuteException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CommandExecuteException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
