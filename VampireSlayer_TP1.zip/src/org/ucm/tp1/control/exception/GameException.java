package org.ucm.tp1.control.exception;

public class GameException extends Exception{

	public GameException() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public GameException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	

}
