package org.ucm.tp1.control.exception;

public class UnvalidPositionException extends CommandExecuteException{


	public UnvalidPositionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
